import fs from 'fs';
import inquirer from 'inquirer';
import chalk from 'chalk';

const TASKS_FILE = './tasks.json';

function loadTasks() {
  if (!fs.existsSync(TASKS_FILE)) return [];
  return JSON.parse(fs.readFileSync(TASKS_FILE, 'utf8'));
}

function saveTasks(tasks) {
  fs.writeFileSync(TASKS_FILE, JSON.stringify(tasks, null, 2));
}

function printTasks(tasks) {
  if (!tasks.length) {
    console.log(chalk.red('Nenhuma tarefa encontrada.'));
    return;
  }

  console.log('\nTarefas:');
  tasks.forEach((task, i) => {
    const status = task.done
      ? chalk.green('[Concluída]')
      : chalk.yellow('[Pendente]');
    console.log(`${i + 1}. ${status} ${task.text}`);
  });
}

async function showMenu() {
  const { action } = await inquirer.prompt([
    {
      type: 'list',
      name: 'action',
      message: 'O que deseja fazer?',
      choices: [
        'Ver tarefas',
        'Adicionar tarefa',
        'Editar tarefa',
        'Excluir tarefa',
        'Marcar tarefa',
        'Sair',
      ],
    },
  ]);

  const tasks = loadTasks();

  switch (action) {
    case 'Ver tarefas':
      printTasks(tasks);
      break;

    case 'Adicionar tarefa': {
      const { task } = await inquirer.prompt([
        { type: 'input', name: 'task', message: 'Digite a tarefa:' },
      ]);
      tasks.push({ text: task, done: false });
      saveTasks(tasks);
      console.log(chalk.green('Tarefa adicionada!'));
      break;
    }

    case 'Editar tarefa': {
      if (!tasks.length) {
        console.log(chalk.red('Sem tarefas para editar.'));
        break;
      }

      const { index } = await inquirer.prompt([
        {
          type: 'list',
          name: 'index',
          message: 'Qual tarefa deseja editar?',
          choices: tasks.map((t, i) => ({
            name: `${i + 1}. ${t.text}`,
            value: i,
          })),
        },
      ]);

      const { newText } = await inquirer.prompt([
        {
          type: 'input',
          name: 'newText',
          message: 'Digite o novo texto da tarefa:',
          default: tasks[index].text,
        },
      ]);

      tasks[index].text = newText;
      saveTasks(tasks);
      console.log(chalk.yellow('Tarefa atualizada.'));
      break;
    }

    case 'Excluir tarefa': {
      if (!tasks.length) {
        console.log(chalk.red('Sem tarefas para excluir.'));
        break;
      }

      const { index } = await inquirer.prompt([
        {
          type: 'list',
          name: 'index',
          message: 'Qual tarefa deseja excluir?',
          choices: tasks.map((t, i) => ({
            name: `${i + 1}. ${t.text}`,
            value: i,
          })),
        },
      ]);

      const removed = tasks.splice(index, 1);
      saveTasks(tasks);
      console.log(chalk.red(`Tarefa removida: ${removed[0].text}`));
      break;
    }

    case 'Marcar tarefa': {
      if (!tasks.length) {
        console.log(chalk.red('Sem tarefas para atualizar.'));
        break;
      }

      const { index } = await inquirer.prompt([
        {
          type: 'list',
          name: 'index',
          message: 'Qual tarefa deseja atualizar?',
          choices: tasks.map((t, i) => ({
            name: `${i + 1}. ${t.text} (${t.done ? 'Concluída' : 'Pendente'})`,
            value: i,
          })),
        },
      ]);

      tasks[index].done = !tasks[index].done;
      saveTasks(tasks);
      console.log(
        tasks[index].done
          ? chalk.green('Tarefa marcada como concluída.')
          : chalk.yellow('Tarefa marcada como pendente.')
      );
      break;
    }

    case 'Sair':
      console.log(chalk.blue('Até logo!'));
      return;

    default:
      console.log(chalk.red('Opção inválida.'));
  }

  await showMenu();
}

showMenu();
