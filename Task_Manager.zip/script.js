let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
let filter = 'all';

function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

function renderTasks() {
  const list = document.getElementById("taskList");
  list.innerHTML = "";

  const filtered = tasks.filter((task) => {
    if (filter === 'pending') return !task.done;
    if (filter === 'done') return task.done;
    return true;
  });

  if (filtered.length === 0) {
    list.innerHTML = "<li>Nenhuma tarefa encontrada.</li>";
    return;
  }

  filtered.forEach((task, i) => {
    const li = document.createElement("li");
    const span = document.createElement("span");
    span.textContent = task.text;
    if (task.done) span.classList.add("done");
    span.onclick = () => toggleTask(i);

    const btns = document.createElement("div");
    btns.className = "buttons";

    const editBtn = document.createElement("button");
    editBtn.textContent = "Editar";
    editBtn.onclick = () => editTask(i);

    const delBtn = document.createElement("button");
    delBtn.textContent = "Excluir";
    delBtn.onclick = () => deleteTask(i);

    btns.appendChild(editBtn);
    btns.appendChild(delBtn);

    li.appendChild(span);
    li.appendChild(btns);
    list.appendChild(li);
  });
}

function addTask() {
  const input = document.getElementById("taskInput");
  const text = input.value.trim();
  if (!text) return alert("Digite uma tarefa.");

  tasks.push({ text, done: false });
  input.value = "";
  saveTasks();
  renderTasks();
}

function editTask(index) {
  const newText = prompt("Editar tarefa:", tasks[index].text);
  if (newText !== null) {
    tasks[index].text = newText.trim();
    saveTasks();
    renderTasks();
  }
}

function deleteTask(index) {
  if (confirm("Deseja excluir esta tarefa?")) {
    tasks.splice(index, 1);
    saveTasks();
    renderTasks();
  }
}

function toggleTask(index) {
  tasks[index].done = !tasks[index].done;
  saveTasks();
  renderTasks();
}

function setFilter(f) {
  filter = f;
  renderTasks();
}

function toggleTheme() {
  document.body.classList.toggle("dark");
  const isDark = document.body.classList.contains("dark");
  document.getElementById("themeToggle").textContent = isDark ? "☀️" : "🌙";
  localStorage.setItem("theme", isDark ? "dark" : "light");
}

function loadTheme() {
  const theme = localStorage.getItem("theme");
  if (theme === "dark") {
    document.body.classList.add("dark");
    document.getElementById("themeToggle").textContent = "☀️";
  }
}

document.getElementById("themeToggle").addEventListener("click", toggleTheme);
loadTheme();
renderTasks();
